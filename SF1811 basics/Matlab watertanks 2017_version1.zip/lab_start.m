%% PREPARE TWO TANK LAB
tankFcn.FreshClear;

%% START TWO TANK LAB
lab = two_tank_app;