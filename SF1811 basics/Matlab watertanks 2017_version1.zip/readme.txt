Run lab_start.m to start the water tank sofware

Software designed for Matlab2017a.